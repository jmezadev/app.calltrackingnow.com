<div class="row">
	<div class="col-xs-12 col-sm-3 col-md-4 col-lg-4">
		<h1 class="page-title txt-color-blueDark">
			
			<!-- PAGE HEADER -->
			<i class="icon-fixed-width icon-home"></i> 
				Website Template
			<span>>  
				Fully Responsive
			</span>
		</h1>
	</div>

</div>

<div class="alert alert-warning">
	The website is fully responsive
</div>

<div class="row">
	<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
		<div class="thumbnail">
			<img src="<?php echo ASSETS_URL; ?>/img/image-placeholder.png" alt="">
			<div class="caption">
				<h4>Thumbnail label</h4>
				<p>
					Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.
				</p>
				<p>
					<a href="goodies/website-template/default/" target="_blank" class="btn btn-default btn-md btn-block">Launch</a>
				</p>
			</div>
		</div>
		
	</div>
	<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
		<div class="thumbnail">
			<img src="<?php echo ASSETS_URL; ?>/img/image-placeholder.png" alt="">
			<div class="caption">
				<h4>Thumbnail label</h4>
				<p>
					Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.
				</p>
				<p>
					<a href="goodies/website-template/default/" target="_blank" class="btn btn-default btn-md btn-block">Launch</a>
				</p>
			</div>
		</div>
	</div>
	<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
		<div class="thumbnail">
			<img src="<?php echo ASSETS_URL; ?>/img/image-placeholder.png" alt="">
			<div class="caption">
				<h4>Thumbnail label</h4>
				<p>
					Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.
				</p>
				<p>
					<a href="goodies/website-template/default/" target="_blank" class="btn btn-default btn-md btn-block">Launch</a>
				</p>
			</div>
		</div>
	</div>
	<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
		<div class="thumbnail">
			<img src="<?php echo ASSETS_URL; ?>/img/image-placeholder.png" alt="">
			<div class="caption">
				<h4>Thumbnail label</h4>
				<p>
					Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.
				</p>
				<p>
					<a href="goodies/website-template/default/" target="_blank" class="btn btn-default btn-md btn-block">Launch</a>
				</p>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	
	// DO NOT REMOVE : GLOBAL FUNCTIONS!
	pageSetUp();
	
	// PAGE RELATED SCRIPTS
	
</script>
